package com.rodriguez.aplicacionfinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Loggin extends AppCompatActivity {

    private FirebaseAuth mAuth;
  private EditText emailEditText;
  private EditText passEditText;

    Button nav_registro;
    Button nuevo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loggin);

        emailEditText = findViewById(R.id.email);
        passEditText= findViewById(R.id.password);

        mAuth = FirebaseAuth.getInstance();


        nav_registro=(Button)findViewById(R.id.nav_registro1);
        nav_registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent atras = new Intent(Loggin.this,MainActivity.class);
                startActivity(atras);
            }
        });


    }
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        updateUI(currentUser);
}

    private void updateUI(FirebaseUser currentUser) {
        Log.i("User",""+currentUser);
    }
    public void signInWithEmailAndPassword(String email,String password){
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("Exito", "signInWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            updateUI(user);
                            nuevo= (Button)findViewById(R.id.loggin);
                            nuevo.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    AlertDialog.Builder alerta = new AlertDialog.Builder(Loggin.this);
                                    alerta.setMessage("Confirma que los datos estan correctos?")
                                            .setCancelable(false)
                                            .setPositiveButton("si", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {
                                                    Intent siguiente = new Intent(Loggin.this,mapas.class);
                                                    startActivity(siguiente);
                                                    finish();
                                                }
                                            })
                                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {
                                                    dialog.cancel();
                                                }
                                            });
                                    AlertDialog titulo = alerta.create();
                                    titulo.setTitle("Iniciar Sesion");
                                    titulo.show();



                                }
                            });
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("Error", "signInWithEmail:failure", task.getException());
                            Toast.makeText(Loggin.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                            updateUI(null);
                        }
                    }
                });
    }
    public void buttonPress(View view){
        String email = emailEditText.getText().toString();
        String pass = passEditText.getText().toString();
        if (!email.isEmpty()&&!pass.isEmpty()){
signInWithEmailAndPassword(email,pass);
        }else{
            Toast.makeText(this, "Llene todos los campos", Toast.LENGTH_SHORT).show();
        }
    }
    }