package com.rodriguez.aplicacionfinal;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.rodriguez.aplicacionfinal.databinding.ActivityMapasBinding;

public class mapas extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapasBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapasBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng punto1 = new LatLng(11.01823,  -74.81141);
        LatLng punto2 = new LatLng(10.997348326791295, -74.81897328476134);
        LatLng punto3 = new LatLng(10.985299688170219, -74.80807278793385);
        LatLng punto4 = new LatLng(10.97629971562371, -74.8392239798445);
        LatLng punto5 = new LatLng(11.039524207979284, -74.90382142893692);
        mMap.addMarker(new MarkerOptions().position(punto1).title("Casa Del Agua sede 1 // Tel: 3187654356"));
        mMap.addMarker(new MarkerOptions().position(punto2).title("Casa Del Agua sede 2 // Tel: 3187687356"));
        mMap.addMarker(new MarkerOptions().position(punto3).title("Casa Del Agua sede 3 // Tel: 3187654356"));
        mMap.addMarker(new MarkerOptions().position(punto4).title("Casa Del Agua sede 4 // Tel: 3187454356"));
        mMap.addMarker(new MarkerOptions().position(punto5).title("Casa Del Agua sede 5 // Tel: 3188709356"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(punto1));
    }
}