package com.rodriguez.aplicacionfinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private EditText emailEditText;
    private EditText passEditText;
    private EditText userEditText;
    Button nav_inicio;
    Button nav_inicio2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        emailEditText = findViewById(R.id.email);
        passEditText = findViewById(R.id.password);
        userEditText = findViewById(R.id.username);

        mAuth = FirebaseAuth.getInstance();
        nav_inicio=(Button)findViewById(R.id.nav_inicio);
        nav_inicio.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent siguiente = new Intent(MainActivity.this,Loggin.class);
                startActivity(siguiente);
            }
        });


    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        updateUI(currentUser);
    }

    private void updateUI(FirebaseUser currentUser) {
        Log.i("user:",""+currentUser);
    }


    public void createUserWithEmailandPassword(String email,String password){

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("Exito", "createUserWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            updateUI(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("Error", "createUserWithEmail:failure", task.getException());
                            Toast.makeText(MainActivity.this, "",
                                    Toast.LENGTH_SHORT).show();
                            updateUI(null);
                        }
                    }
                });


    }


    public void buttonPress(View view){
        String email = emailEditText.getText().toString();
        String pass = passEditText.getText().toString();
        String user = userEditText.getText().toString();

        if (!email.isEmpty()&&!pass.isEmpty()&&!user.isEmpty()){
            if (pass.length() >=6 ){
                createUserWithEmailandPassword(email,pass);
                Toast.makeText(this,"Cuenta creada con exito!", Toast.LENGTH_SHORT).show();
                Intent siguiente = new Intent(MainActivity.this,Loggin.class);
                startActivity(siguiente);}
            else {Toast.makeText(this,"Ingrese una clave mayor o igual a 6 caracteres",Toast.LENGTH_SHORT).show();

            }}else{
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
        }


    }
}